﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventorySimulator22.InventorySimulator;


namespace InventorySimulator
    {
        class Program
        {
            static List<InventoryItem> inventory = new List<InventoryItem>();

            static void Main(string[] args)
            {
                bool exit = false;

                while (!exit)
                {
                    Console.Clear();
                    Console.WriteLine("===== Inventory Menu =====");
                    Console.WriteLine("1. Insert a new item");
                    Console.WriteLine("2. Display an item");
                    Console.WriteLine("3. Display all items");
                    Console.WriteLine("4. Exit");
                    Console.Write("Enter your choice (1-4): ");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            InsertItem();
                            break;
                        case "2":
                            DisplayItem();
                            break;
                        case "3":
                            DisplayAllItems();
                            break;
                        case "4":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid option. Press any key to try again.");
                            Console.ReadKey();
                            break;
                    }
                }
            }

            static void InsertItem()
            {
                do
                {
                    string id;
                    do
                    {
                        Console.Write("Enter 3-digit ID: ");
                        id = Console.ReadLine();
                    } while (string.IsNullOrWhiteSpace(id) || id.Length != 3 || !int.TryParse(id, out _));

                    Console.Write("Enter short name: ");
                    string shortName = Console.ReadLine();

                    Console.Write("Enter long description: ");
                    string longDesc = Console.ReadLine();

                    double price;
                    while (true)
                    {
                        Console.Write("Enter price: ");
                        if (double.TryParse(Console.ReadLine(), out price)) break;
                        Console.WriteLine("Invalid price. Try again.");
                    }

                    InventoryItem newItem = new InventoryItem
                    {
                        ID = id,
                        ShortName = shortName,
                        LongDescription = longDesc,
                        Price = price
                    };

                    inventory.Add(newItem);
                    Console.Write("Item added. Add another item? (y/n): ");
                } while (Console.ReadLine().ToLower() == "y");
            }

            static void DisplayItem()
            {
                Console.Write("Enter item ID to display: ");
                string id = Console.ReadLine();

                InventoryItem item = inventory.Find(i => i.ID == id);

                if (item != null)
                {
                    Console.WriteLine("\nItem Details:");
                    Console.WriteLine(item);
                }
                else
                {
                    Console.WriteLine("Item not found.");
                }

                Console.WriteLine("Press any key to return to menu...");
                Console.ReadKey();
            }

            static void DisplayAllItems()
            {
                if (inventory.Count == 0)
                {
                    Console.WriteLine("No items in inventory.");
                }
                else
                {
                    Console.WriteLine("\nAll Inventory Items:");
                    Console.WriteLine("ID\tShortName\tLongDescription\t\tPrice");

                    foreach (InventoryItem item in inventory)
                    {
                        Console.WriteLine($"{item.ID}\t{item.ShortName}\t\t{item.LongDescription}\t\t${item.Price:F2}");
                    }
                }

                Console.WriteLine("\nPress any key to return to menu...");
                Console.ReadKey();
            }
        }
    }


       

