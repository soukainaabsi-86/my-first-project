﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventorySimulator22
{
    using System;

    namespace InventorySimulator
    {
        public class InventoryItem
        {
            public string ID { get; set; }
            public string ShortName { get; set; }
            public string LongDescription { get; set; }
            public double Price { get; set; }

            public override string ToString()
            {
                return $"ID: {ID}\nShort Name: {ShortName}\nLong Description: {LongDescription}\nPrice Amount: ${Price:F2}";
            }
        }
    }

}
